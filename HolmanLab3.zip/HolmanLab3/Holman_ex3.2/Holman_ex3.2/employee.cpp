#include "employee.h"
#include <iostream>
#include <string>
/*
void employee::enterEmployeeName(std::string* name, int size) {
	std::cout << "Enter The Employee Name" << std::endl; 
	for (int i = 0; i < size; i++) {
		std::cin >> name[i]; 

	}


}

void employee::enterEmployeeSSN(std::string* ssn, int size) {
	std::cout << "Enter The Employee SSN" << std::endl;
	for (int i = 0; i < size; i++) {
		std::cin >> ssn[i];

	}
}

void employee::displayEmployeeInformation(std::string* name, std::string* ssn, int size) {
	std::cout << "Employee Name: \n"; 
	for (int i = size; i > 0; i--) {
		std::cout << name[i - 1] << std::endl; 
	}
	std::cout << "\n"; 
	std::cout << "Employee SSN: \n"; 
	for (int i = size; i > 0; i--) {
		std::cout << ssn[i - 1] << std::endl; 
	}
}
*/