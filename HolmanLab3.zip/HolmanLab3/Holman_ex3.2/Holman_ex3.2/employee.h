#pragma once
#include <string>
class employee
{
public: 
	//void enterEmployeeName(std::string* name, int size);
	//void enterEmployeeSSN(std::string* ssn, int size);
	//void displayEmployeeInformation(std::string* name, std::string* ssn, int size);
	std::string employee_name;
	std::string employee_ssn;
private: 
	//std::string employee_name; 
	//std::string employee_ssn; 
};

