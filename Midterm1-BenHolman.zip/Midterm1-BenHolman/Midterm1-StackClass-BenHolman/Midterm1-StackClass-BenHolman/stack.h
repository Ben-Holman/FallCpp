#pragma once
#include <string>
// Part 1 Ben Holman
#define MAX_STACK 6 
class stack
{
protected:
	int intStack[MAX_STACK] = { 0, };
	int top;
	char d;
	std::string a;

public:
	stack();
	~stack();
	std::string setString(std::string b);
	std::string getString();
	int push(int x);
	void display(std::string s);
	int pop();
	int Top();
	int isEmpty();
	int isFull();
};

/*
Write a stack class. The stack class must include at least �push�, �pop�, �top�, �isEmpty�, �isFull�
methods. You can implement any additional methods, as they needed. Write your class in stack.h
and stack.cpp. The part 1 does not needed to be tested.
*/

// NON-MEMBER FUNCTIONS 
int precedence(char a);

void postfix(std::string a);

bool isBalanced(std::string expr); 
