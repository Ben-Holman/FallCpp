//Part 2 Ben Holman 
// Date Started: 9/30/2022
// Date of Last Edit: 10/3/2022
//=============================================ASSIGNMENT===============================================\\ 
/*
	Create the postfix.cpp file the converts an infix expression into a postfix expression. You must use
	the stack.h and stack.cpp implemented in Part 1. The program must allow the user inputs, and the
	inputs should not include any alphabets. You need to handle �(�, �)�, �+�, �-�, �/�, �*� and �%�
	operators. �^� will not be considered in this program. Also, please consider only one digit numbers.
*/

#include <iostream>
#include <string>
#include "stack.h"
// COMMENT ALL THE LINES TO EXPLAIN THE CODE
int main()
{
    //stack stk;
    
    //int choice, n, temp;
    std::string expression; //results;

    // code for lines 24 - 70 from https://iq.opengenus.org/implement-stack-in-cpp/ 
    /*
    do // do-while statement that lets the user input into the stack
    {
        // print statements 
        std::cout << std::endl;
        std::cout << "0 - Exit." << std::endl;
        std::cout << "1 - Push Item." << std::endl;
        std::cout << "2 - Pop Item." << std::endl;
        std::cout << "3 - Display Items (Print STACK)." << std::endl;
        std::cout << "4 - Postfix Items." << std::endl;
        // getting the users choice for the Switch-statement
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) // here's the switch-statement that uses the 'choice' variable
        {
        case 0: break;

        case 1: // Case 1: pushing an item
            std::cout << "Enter item to insert: ";
            std::cin >> n;
            temp = stk.push(n); // temp variable calls the push function for stk.
            if (temp == -9999) // if the user enter this then a stack overflow will occur
                std::cout << "STACK OVERFLOW - STACK IMPLEMENTATION ERROR" << std::endl;
            else
                std::cout << temp << " inserted." << std::endl; // if the user does not enter -9999 then the item they entered is put into the stack
            break;

        case 2:
            temp = stk.pop(); // temp calls the pop function for stk
            if (temp == -9999) // if the user tries to pop -9999 then a stack underflow occurs
                std::cout << "STACK UNDERFLOW - STACK ADT ERROR" << std::endl;
            else
                std::cout << temp << " is removed (popped)." << std::endl; // if -9999 is not entered than the item, temp, is popped.
            break;

        case 3:
            //stk.display(); // displays the stack 
            break;
        case 4:
            std::cout << "Enter a mathmatical expression: NO SPACES\n"; 
            std::cin >> expression; 
            //getline(std::cin, expression);
            postfix(expression); 
        default:
            std::cout << "An Invalid choice." << std::endl; 
        }
    } while (choice != 0);
    */
   
    std::cout << "Enter a mathmatical expression: NO SPACES\n";
    std::cin >> expression;
    //getline(std::cin, expression);
    postfix(expression);
    //the test cases are strings to make the testing easier and faster, but the user can input strings. 
    std::string test1 = "2+3*4";
    std::string test2 = "(1+2)*7";
    std::string test3 = "a*b+c";
    std::string test4 = "(7+8*7";
    std::string test5 = "(9+7)4";
    std::string test6 = "2*4*8/";
    std::cout << test1 << std::endl;
    postfix(test1);
    std::cout << std::endl; 
    std::cout << test2 << std::endl;
    postfix(test2);
    std::cout << std::endl;
    std::cout << test3 << std::endl;
    postfix(test3);
    std::cout << std::endl;
    std::cout << test4 << std::endl;
    postfix(test4);
    std::cout << std::endl;
    std::cout << test5 << std::endl;
    postfix(test5);
    std::cout << std::endl;
    std::cout << test6 << std::endl;
    postfix(test6);
    std::cout << std::endl;
      // std::string exp1 = "a+b*(c^d-e)^(f+g*h)-i";
      // Function call
      // postfix(exp1);
        std::cout << std::endl;
        return 0;
}


/*
				Output
	Enter an infix expression: 2 + 3 * 4
	The postfix form is 2 3 4 * +

	Enter an infix expression: (1 + 2) * 7
	The postfix form is 1 2 + 7 *

	Enter an infix expression: a * b + c
	I cannot create a postfix form - Error

	Enter an infix expression: ( 7 + 8 * 7
	I cannot create a postfix form - Error

	Enter an infix expression: ( 9 + 7 ) 4
	I cannot create a postfix form - Error

	Enter an infix expression: 2 * 4 * 8 /
	I cannot create a postfix form - Error
*/