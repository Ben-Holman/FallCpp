#include "stack.h"
#include <iostream>
#include <string>

stack::stack() { // code from https://iq.opengenus.org/implement-stack-in-cpp/
	top = -1;
}

stack::~stack() {
	std::cout << "This is the Destructor!." << std::endl;
}

std::string stack::setString (std::string b) {
	return b = a;
}

std::string stack::getString() {
	return a;
}


/*
|************************************************************************|
|							CODE FOR 'PUSH' FROM 				         |
|             https://iq.opengenus.org/implement-stack-in-cpp/           |
|************************************************************************|
*/
// Comment
int stack::push(int x) {
	if (isFull()) // checks to see if isFull() is true
	{
		return -9999; // if it is then return -9999
	}
	++top; // if not, then add to top
	intStack[top] = x; // intStack at top will be assigned to the variable x
	return x;
}
/*
|************************************************************************|
|							CODE FOR 'POP' FROM 				         |
|             https://iq.opengenus.org/implement-stack-in-cpp/           |
|************************************************************************|
*/
// Comment the code 
int stack::pop() {
	int temp; // creates the temp variable 
	if (isEmpty()) // checks to see if isEmpty() is true
		return -9999; // if it is then return -9999
	temp = intStack[top]; // if not then pop the item at the top.
	--top; // decrease top
	return temp;
}
// 'Top' taken from https://stackoverflow.com/questions/21245455/how-do-i-implement-the-stacktop-function "Since you already store top, you can just return p[top]. 
//Or in other words: top() would essentially be the same as pop(), it just won't remove the top element."

int stack::Top() {
	int temp; // creates the temp variable 
	if (isEmpty()) // checks to see if isEmpty() is true
		return -9999; // if it is then return -9999
	temp = intStack[top]; // if not then pop the item at the top.
	//--top; // decrease top
	return temp;
}
// lecture slides
int stack::isEmpty() {
	return (top == -1);
}
// lecture slides
int stack::isFull() {
	return (top == (MAX_STACK - 1));
}

/*
|************************************************************************|
|							CODE FOR 'DISPLAY' FROM 				     |
|             https://iq.opengenus.org/implement-stack-in-cpp/           |
|************************************************************************|
*/

void stack::display(std::string s) {
	int i;
	std::cout << "STACK is: ";
	for (i = (top); i >= 0; i--)
		std::cout << intStack[i] << " ";
	std::cout << std::endl;
}

/*
|************************************************************************|
|							CODE FOR 'POSTFIX' FROM 				     |
|          https://www.geeksforgeeks.org/stack-set-2-infix-to-postfix/   |
|************************************************************************|
*/

void postfix(std::string c) { // COMMENT CODE
	stack fix; // creating a new 'stack' object. 
	fix.setString(c); // sets the 'fix' object to have the string value of c parameter
	std::string results; // declare the 'results' string variable 

	for (int i = 0; i < c.length(); i++) { // a for-loop that runs through the length of the string, c, and assigns the characters of that string to char 's'
		char s = c[i];
		
		if (/*(s >= 'a' && s <= 'z') || (s >= 'A' && s <= 'Z') || */ (s >= '0' && s <= '9')) { // this checks the 's' variable to see if any one the characters are above '0' and less than '9' 
			results += s; // the characters of 's' being placed into string 'results' 
		}
		else if ((s >= 'a' && s <= 'z') || (s >= 'A' && s <= 'Z')) { // this if statement checks to see if there are any NaN characters and if there are to put out an error. 
			std::cout << "Error! NaN detected in String.";
			//exit(1);
		}
		else if (s == '(') {  // if one of the scanned characters of the string matches, then it is pushed onto the stack
			fix.push('(');
			if (isBalanced(results)) { // checks to see if there is a corresponding symbol
				std::cout << "Error! Characters Do Not Match" << std::endl;
			}
		}
		else if (s == ')') { // if one of the scanned characters of the string matches, then it is pushed onto the stack 
			if (isBalanced(results)) { //checks to see if there is a corresponding symbol
				std::cout << "Error! Characters Do Not Match" << std::endl;
			}
			while (fix.Top() != '(') { // if this does not appear in the string then results is set to += Top()
				results += fix.Top(); 
				fix.pop(); // pops the symbol out of the stack
			}
			fix.pop(); // pops the symbol out of the stack. That is why, at the end result, you do not see the '()'
		}
		else {
			while (!fix.isEmpty() && precedence(c[i]) <= precedence(fix.Top())) { // the loop checks to see if the stack is empty and if the precedence from the 
																					   // precedence function of 'c' is less or equal to the precedence of the character 
																					   //on the top of the stack.
				results += fix.Top();
				fix.pop();
			}
			fix.push(s);
		}
	}

	while (! fix.isEmpty()) {
		results += fix.Top();
		fix.pop();
	}
	//fix.display(results);
	std::cout << results << std::endl;
}
/*
|*************************************************************************|
|							CODE FOR 'PRECEDENCE' FROM 				      |
|          https://www.geeksforgeeks.org/stack-set-2-infix-to-postfix/    |
|*************************************************************************|
*/
// Comment Code
int precedence(char a) {
	// this function follows the precedence rules of PEMDAS, specifically with the multiplication, division, addition, subtraction
	if (a == '/' || a == '*' || a == '%') { // if there are characters that match the multiplication or division symbols, they have a higher pecedence of '2'
		return 2;
	}
	else if (a == '+' || a == '-') { // if there are symbols that match the addition or subtraction symbols, then they have a lower precdence of '1'
		return 1;
	}
	else {
		return -1; // if there's no symbols that match the ones above, the lowest precedence of '-1' is returned
	}
}
/*
|**************************************************************************************************|
|							CODE FOR 'ISBALANCED' FROM 				                               |
|https://www.tutorialspoint.com/cplusplus-program-to-check-for-balanced-paranthesis-by-using-stacks|
|**************************************************************************************************|
*/
bool isBalanced(std::string expr) { // Comment Code 
	stack s;
	s.setString(expr);
	char ch;
	for (int i = 0; i < expr.length(); i++) {    //for-loop that runs through the string and checks to see if any of these characters match
		if (expr[i] == '(' || expr[i] == '[' || expr[i] == '{') {  // if any of these symbols match, put them onto the stack.
			s.push(expr[i]);
			continue;
		}
		if (s.isEmpty())    //stack ccn't be empty because there needs to be a closing bracket 
			return false;
		switch (expr[i]) {
		case ')':    //the closing paranthesis is popped out and checks to see if there is an opening bracket or brace 
			ch = s.Top();
			s.pop();
			if (ch == '{' || ch == '[')
				return false;
			break;
		case '}': //the closing brace is popped out and checks to see if there are opening paranthesese and brackets
			ch = s.Top();
			s.pop();
			if (ch == '(' || ch == '[')
				return false;
			break;
		case ']': //the closing bracket is popped out and it checks to see if there are opening paraentheses and braces.
			ch = s.Top();
			s.pop();
			if (ch == '(' || ch == '{')
				return false;
			break;
		}
	}
	return (s.isEmpty()); //when the stack is empty -- return 'true' 
}