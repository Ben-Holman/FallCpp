
#pragma once 
#include "dateClass.h"

using namespace dateSpace;
void displayDate(dateClass date);