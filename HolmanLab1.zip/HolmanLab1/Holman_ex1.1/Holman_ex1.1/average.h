#pragma once

double average(int num_scores, double sum);