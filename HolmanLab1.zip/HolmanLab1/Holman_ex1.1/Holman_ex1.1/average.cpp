#pragma once
#include "average.h"

double average(int num_scores, double sum){ // NO SEMICOLON HERE! 
/* computes the average using an already computed sum and num_scores */
return sum / num_scores;
}
